package com.example.listadetelefones

interface ClickItemContactListener {
    fun clickItemContact(contact: Contact)
}